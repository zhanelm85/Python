def config():
    return {
        'host': 'localhost',
        'database': 'phonebook',
        'user': 'postgres',
        'password': '4268',
        'port': 5432
    }


